<?php

function mithaecus_recipes_admin_scripts() {
	$screen = get_current_screen();

	if ( $screen->base !== 'post' ) return;

	if ( $screen->post_type === 'mithaecus_recipe' ) {
		wp_enqueue_script( 'mithaecus-recipes-admin-scripts', plugins_url(
			'mithaecus-recipes/dist/assets/js/admin.js'
		), array( 'jquery' ),'20190923', true );
	}
	
}

add_action( 'admin_enqueue_scripts', 'mithaecus_recipes_admin_scripts' );