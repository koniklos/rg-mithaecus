<?php

function mithaecus_recipes_admin_scripts() {
	global $pagenow;
	global $post;

	if ( $pagenow !== 'post.php' ) {
		return;
	}

	if ( $post->post_type === 'mithaecus_recipe' ) {
		// Enqueue...

		wp_enqueue_script( 'mithaecus-recipes-admin-scripts', plugins_url(
			'mithaecus-recipes/dist/assets/js/admin.js'
		), array( 'jquery' ), date('ydmGis'), true );
	
		// wp_enqueue_style( 'mithaecus-recipes-admin-stylesheets', plugins_url(
		// 	'mithaecus-metaboxes/dist/assets/css/admin.css'
		// ), array(), date('ydmGis'), 'all' );
	}
	
}

add_action( 'admin_enqueue_scripts', 'mithaecus_recipes_admin_scripts' );