<?php

function mithaecus_recipes_setup_post_type() {
	$labels = array(
		'name'                  => esc_html_x( 'Recipes', 'Post type general name', 'mithaecus-recipes' ),
		'singular_name'         => esc_html_x( 'Recipe', 'Post type singular name', 'mithaecus-recipes' ),
		'menu_name'             => esc_html_x( 'Recipes', 'Admin Menu text', 'mithaecus-recipes' ),
		'name_admin_bar'        => esc_html_x( 'Recipe', 'Add New on Toolbar', 'mithaecus-recipes' ),
		'add_new'               => esc_html__( 'Add New', 'mithaecus-recipes' ),
		'add_new_item'          => esc_html__( 'Add New Recipe', 'mithaecus-recipes' ),
		'new_item'              => esc_html__( 'New Recipe', 'mithaecus-recipes' ),
		'edit_item'             => esc_html__( 'Edit Recipe', 'mithaecus-recipes' ),
		'view_item'             => esc_html__( 'View Recipe', 'mithaecus-recipes' ),
		'view_items'            => esc_html__( 'View Recipes', 'mithaecus-recipes' ),
		'all_items'             => esc_html__( 'All Recipes', 'mithaecus-recipes' ),
		'search_items'          => esc_html__( 'Search Recipes', 'mithaecus-recipes' ),
		'parent_item_colon'     => esc_html__( 'Parent Recipes:', 'mithaecus-recipes' ),
		'not_found'             => esc_html__( 'No Recipes found.', 'mithaecus-recipes' ),
		'not_found_in_trash'    => esc_html__( 'No Recipes found in Trash.', 'mithaecus-recipes' ),
		'featured_image'        => esc_html_x( 'Recipe Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'mithaecus-recipes' ),
		'set_featured_image'    => esc_html_x( 'Set recipe image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'mithaecus-recipes' ),
		'remove_featured_image' => esc_html_x( 'Remove recipe image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'mithaecus-recipes' ),
		'use_featured_image'    => esc_html_x( 'Use as recipe image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'mithaecus-recipes' ),
		'archives'              => esc_html_x( 'Recipe archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'mithaecus-recipes' ),
		'insert_into_item'      => esc_html_x( 'Insert into recipe', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'mithaecus-recipes' ),
		'uploaded_to_this_item' => esc_html_x( 'Uploaded to this recipe', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'mithaecus-recipes' ),
		'filter_items_list'     => esc_html_x( 'Filter recipes list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'mithaecus-recipes' ),
		'items_list_navigation' => esc_html_x( 'Recipes list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'mithaecus-recipes' ),
		'items_list'            => esc_html_x( 'Recipes list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'mithaecus-recipes' ),
	);
	
	$args = array(
		'labels' => $labels,
		'public' => true,
    'has_archive' => true,
    'menu_icon' => 'dashicons-book-alt',
		'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
		'rewrite' => array( 'slug' => 'recipes' ),
		'show_in_rest' => true,
		'taxonomies'  => array( 'category', 'post_tag' )
	);

	register_post_type( 'mithaecus_recipe', $args );
}

add_action( 'init', 'mithaecus_recipes_setup_post_type' );