<?php

function mithaecus_recipes_register_course_type_tax() {
	$labels = array(
		'name'              => esc_html_x('Couse Type', 'taxonomy general name', 'mithaecus-recipes'),
		'singular_name'     => esc_html_x('Couse Type', 'taxonomy singular name', 'mithaecus-recipes'),
		'search_items'      => esc_html__('Search Couse Types', 'mithaecus-recipes'),
		'all_items'         => esc_html__('All Couse Types', 'mithaecus-recipes'),
		'parent_item'       => esc_html__('Parent Couse Type', 'mithaecus-recipes'),
		'parent_item_colon' => esc_html__('Parent Couse Type:', 'mithaecus-recipes'),
		'edit_item'         => esc_html__('Edit Couse Type', 'mithaecus-recipes'),
		'update_item'       => esc_html__('Update Couse Type', 'mithaecus-recipes'),
		'add_new_item'      => esc_html__('Add New Couse Type', 'mithaecus-recipes'),
		'new_item_name'     => esc_html__('New Couse Type Name', 'mithaecus-recipes'),
		'menu_name'         => esc_html__('Couse Types', 'mithaecus-recipes'),
	);
	
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
		'show_admin_column' => true,
		'rewrite' => array('slug' => 'course'),
		'show_in_rest' => true
	);
	
	register_taxonomy('mithaecus_course_type', array('mithaecus_recipe'), $args);
}

add_action('init', 'mithaecus_recipes_register_course_type_tax');