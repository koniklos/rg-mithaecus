<?php

function mithaecus_recipes_register_seasonals_tax() {
	$labels = array(
		'name'              => esc_html_x('Seasonals', 'taxonomy general name', 'mithaecus-recipes'),
		'singular_name'     => esc_html_x('Season', 'taxonomy singular name', 'mithaecus-recipes'),
		'search_items'      => esc_html__('Search Seasonals', 'mithaecus-recipes'),
		'all_items'         => esc_html__('All Seasonals', 'mithaecus-recipes'),
		'parent_item'       => esc_html__('Parent Season', 'mithaecus-recipes'),
		'parent_item_colon' => esc_html__('Parent Season:', 'mithaecus-recipes'),
		'edit_item'         => esc_html__('Edit Season', 'mithaecus-recipes'),
		'update_item'       => esc_html__('Update Season', 'mithaecus-recipes'),
		'add_new_item'      => esc_html__('Add New Season', 'mithaecus-recipes'),
		'new_item_name'     => esc_html__('New Season Name', 'mithaecus-recipes'),
		'menu_name'         => esc_html__('Seasonals', 'mithaecus-recipes'),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'seasonal' ),
		'show_in_rest'      => true
	);
		
	register_taxonomy('mithaecus_seasonal', array('mithaecus_recipe'), $args);
}

add_action('init', 'mithaecus_recipes_register_seasonals_tax');