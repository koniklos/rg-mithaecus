<?php

function mithaecus_recipes_register_meal_type_tax() {
	$labels = array(
		'name'              => esc_html_x('Meal Type', 'taxonomy general name', 'mithaecus-recipes'),
		'singular_name'     => esc_html_x('Meal Type', 'taxonomy singular name', 'mithaecus-recipes'),
		'search_items'      => esc_html__('Search Meal Types', 'mithaecus-recipes'),
		'all_items'         => esc_html__('All Meal Types', 'mithaecus-recipes'),
		'parent_item'       => esc_html__('Parent Meal Type', 'mithaecus-recipes'),
		'parent_item_colon' => esc_html__('Parent Meal Type:', 'mithaecus-recipes'),
		'edit_item'         => esc_html__('Edit Meal Type', 'mithaecus-recipes'),
		'update_item'       => esc_html__('Update Meal Type', 'mithaecus-recipes'),
		'add_new_item'      => esc_html__('Add New Meal Type', 'mithaecus-recipes'),
		'new_item_name'     => esc_html__('New Meal Type Name', 'mithaecus-recipes'),
		'menu_name'         => esc_html__('Meal Types', 'mithaecus-recipes'),
	);
	
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
		'show_admin_column' => true,
		'rewrite' => array('slug' => 'meal'),
		'show_in_rest' => true
	);
	
	register_taxonomy('mithaecus_meal_type', array('mithaecus_recipe'), $args);
}

add_action('init', 'mithaecus_recipes_register_meal_type_tax');