<?php

function mithaecus_recipes_register_ingredients_tax() {
	$labels = array(
		'name'              => esc_html_x('Ingredients', 'taxonomy general name', 'mithaecus-recipes'),
		'singular_name'     => esc_html_x('Ingredient', 'taxonomy singular name', 'mithaecus-recipes'),
		'search_items'      => esc_html__('Search Ingredients', 'mithaecus-recipes'),
		'all_items'         => esc_html__('All Ingredients', 'mithaecus-recipes'),
		'parent_item'       => esc_html__('Parent Ingredient', 'mithaecus-recipes'),
		'parent_item_colon' => esc_html__('Parent Ingredient:', 'mithaecus-recipes'),
		'edit_item'         => esc_html__('Edit Ingredient', 'mithaecus-recipes'),
		'update_item'       => esc_html__('Update Ingredient', 'mithaecus-recipes'),
		'add_new_item'      => esc_html__('Add New Ingredient', 'mithaecus-recipes'),
		'new_item_name'     => esc_html__('New Ingredient Name', 'mithaecus-recipes'),
		'menu_name'         => esc_html__('Ingredients', 'mithaecus-recipes'),
	);

	$args = array(
		'hierarchical'      => false,
		'labels'            => $labels,
		'show_admin_column' => false,
		'rewrite'           => array( 'slug' => 'ingredients' ),
		'show_in_rest'      => true
	);
		
	register_taxonomy('mithaecus_ingredients', array('mithaecus_recipe'), $args);
}

add_action('init', 'mithaecus_recipes_register_ingredients_tax');