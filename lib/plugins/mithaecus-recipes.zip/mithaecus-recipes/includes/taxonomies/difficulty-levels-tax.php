<?php

function mithaecus_recipes_register_difficulty_levels_tax() {
	$labels = array(
		'name'              => esc_html_x('Difficulty Levels', 'taxonomy general name', 'mithaecus-recipes'),
		'singular_name'     => esc_html_x('Difficulty Level', 'taxonomy singular name', 'mithaecus-recipes'),
		'search_items'      => esc_html__('Search Difficulty Levels', 'mithaecus-recipes'),
		'all_items'         => esc_html__('All Difficulty Levels', 'mithaecus-recipes'),
		'parent_item'       => esc_html__('Parent Difficulty Level', 'mithaecus-recipes'),
		'parent_item_colon' => esc_html__('Parent Difficulty Level:', 'mithaecus-recipes'),
		'edit_item'         => esc_html__('Edit Difficulty Level', 'mithaecus-recipes'),
		'update_item'       => esc_html__('Update Difficulty Level', 'mithaecus-recipes'),
		'add_new_item'      => esc_html__('Add New Difficulty Level', 'mithaecus-recipes'),
		'new_item_name'     => esc_html__('New Difficulty Level Name', 'mithaecus-recipes'),
		'menu_name'         => esc_html__('Difficulty Levels', 'mithaecus-recipes'),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'difficulty' ),
		'show_in_rest'      => true
	);
		
	register_taxonomy('mithaecus_difficulty', array('mithaecus_recipe'), $args);
}

add_action('init', 'mithaecus_recipes_register_difficulty_levels_tax');