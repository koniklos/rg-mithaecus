<?php

function mithaecus_serves_add_meta_box() {
	add_meta_box(
		'mithaecus-recipes_serves',
		esc_html__( 'Serves', 'mithaecus-recipes' ),
		'mithaecus_serves_html',
		'mithaecus_recipe',
		'side',
		'default',
		array(
			'__block_editor_compatible_meta_box' => true,
			'__back_compat_meta_box'             => false,
		)
	);
}

add_action( 'add_meta_boxes', 'mithaecus_serves_add_meta_box' );

function mithaecus_serves_html( $post ) {
	$serves = get_post_meta( $post->ID,'mithaecus-recipes_serves', true );
	wp_nonce_field( 'mithaecus_serves', 'mithaecus_serves_nonce' );
	?>
	<p>
		<label for="mithaecus-recipes_serves"><?php _e( 'Serves', 'mithaecus-recipes' ); ?></label><br>
		<input class="widefat" rows="7" name="mithaecus-recipes_serves" id="mithaecus-recipes_serves" type="number" min="0" value="<?php echo esc_attr( $serves ); ?>"/>
	
	</p><?php
}

function mithaecus_serves_save( $post_id, $post ) {
	$can_edit = get_post_type_object( $post->post_type )->cap->edit_post;
	if ( ! isset( $_POST['mithaecus_serves_nonce'] ) || ! wp_verify_nonce( $_POST['mithaecus_serves_nonce'], 'mithaecus_serves' ) ) return;
	if ( ! current_user_can( $can_edit, $post_id ) ) return;

	if ( isset( $_POST['mithaecus-recipes_serves'] ) )
		update_post_meta( $post_id, 'mithaecus-recipes_serves', sanitize_text_field( $_POST['mithaecus-recipes_serves'] ) );
}

add_action( 'save_post', 'mithaecus_serves_save', 10, 2 );