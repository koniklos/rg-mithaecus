<?php

require_once get_template_directory() . '/lib/class-tgm-plugin-activation.php';

function mithaecus_register_plugins() {
	$plugins = array(
		array(
			'name' 							 => 'mithaecus post layout metabox',
			'slug' 							 => 'mithaecus-post-layout-metabox',
			'source' 						 => get_template_directory_uri() . '/lib/plugins/mithaecus-post-layout-metabox.zip',
			'required' 					 => true,
			'version' 					 => '0.0.1',
			'force_activation' 	 => false,
			'force_deactivation' => false,
		),
		array(
			'name' 							 => 'mithaecus recipes',
			'slug' 							 => 'mithaecus-recipes',
			'source' 						 => get_template_directory_uri() . '/lib/plugins/mithaecus-recipes.zip',
			'required' 					 => true,
			'version' 					 => '0.0.1',
			'force_activation' 	 => false,
			'force_deactivation' => false,
		)
	);

	$config = array();

	tgmpa( $plugins, $config );
}

add_action( 'tgmpa_register', 'mithaecus_register_plugins' );