<?php

function mithaecus_assets() {
	wp_enqueue_style( 'mithaecus-stylesheet', get_template_directory_uri() . 
	'/dist/assets/css/bundle.css', array(), '20190922', 'all' );

	// wp_enqueue_script( 'mithaecus-lazyload', get_template_directory_uri() . 
	// '/dist/assets/js/lazyload.js', array(), date('ydmGis'), true );

	wp_enqueue_script( 'mithaecus-scripts', get_template_directory_uri() . 
	'/dist/assets/js/bundle.js', array('jquery'), '20190922', true );

	wp_enqueue_script( 'mithaecus-modernizr', get_template_directory_uri() . 
	'/dist/assets/js/modernizr-build.js', array(), '20190922', false );



	// Comment Reply for singular post/pages where comments are open
	// and the thread comments option in admin is enabled
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}

add_action('wp_enqueue_scripts', 'mithaecus_assets');

function mithaecus_customize_preview_script() {
	wp_enqueue_script('mithaecus-customize_preview', get_template_directory_uri() . 
	'/dist/assets/js/customize-preview.js', 
	array('customize-preview', 'jquery'), '20190922', true);
}

add_action('customize_preview_init', 'mithaecus_customize_preview_script');