<?php

function mithaecus_sanitize_site_info( $input ) {
	$allowed = array('a' => array(
		'href' => array(),
		'title' => array()
	));

	return wp_kses( $input, $allowed );
}

function mithaecus_sanitize_footer_background( $input ) {
	$valid = array('light', 'dark');

	if ( in_array($input, $valid, true) ) {
		return $input;
	}

	return 'dark';
}

function mithaecus_validate_footer_layout( $validity, $value ) {
	if (!preg_match('/^([1-9]|1[012])(,([1-9]|1[012]))*$/', $value)) {
		$validity->add('invalid_footer_layout', esc_html__( 'The footer layout is not valid', 'mithaecus' ));
	}

	return $validity;
}

function mithaecus_customize_register( $wp_customize ) {
	// Website name
	$wp_customize->get_setting('blogname')->transport = 'postMessage';

	$wp_customize->selective_refresh->add_partial('blogname', array(
		'selector' => '.main-header__blogname',
		'container_inclusive' => false,
		'render_callback' => function() {	bloginfo( 'name' );	}
	));

	// Single page layout section
	$wp_customize->add_section('mithaecus_single_blog_options', array(
		'title' => esc_html__( 'Single Blog Options', 'mithaecus' ),
		'description' => esc_html__( 'Change single page layout', 'mithaecus' ),
		'active_callback' => 'mithaecus_show_single_blog_section'
	));

	$wp_customize->add_setting('mithaecus_display_author_info', array(
		'default' => true,
		'transport' => 'postMessage',
		'sanitize_callback' => 'mithaecus_sanitize_checkbox'
	));

	$wp_customize->add_control('mithaecus_display_author_info', array(
		'type' => 'checkbox',
		'label' => esc_html__( 'Show Author Info', 'mithaecus' ),
		'section' => 'mithaecus_single_blog_options'
	));

	function mithaecus_sanitize_checkbox( $checked ) {
		return ( isset($checked) && $checked === true ) ? true : false;
	}

	function mithaecus_show_single_blog_section() {
		global $post;
		return is_single() && $post->post_type === 'post';
	}

	// Footer options section
	$wp_customize->add_section('mithaecus_footer_options', array(
		'title' => esc_html__( 'Footer Options', 'mithaecus' ),
		'description' => esc_html__( 'Change footer options', 'mithaecus' )
	));

	$wp_customize->selective_refresh->add_partial('mithaecus_footer_partial', array(
		'settings' => array('mithaecus_footer_background', 'mithaecus_footer_layout'),
		'selector' => '#footer',
		'container_inclusive' => false,
		'render_callback' => function() {
			get_template_part( 'template-parts/footer/widgets' );
			get_template_part( 'template-parts/footer/info' );
		}
	));

	$wp_customize->add_setting('mithaecus_site_info', array(
		'default' => '',
		'sanitize_callback' => 'mithaecus_sanitize_site_info',
		'transport' => 'postMessage'
	));

	$wp_customize->add_control('mithaecus_site_info', array(
		'type' => 'text',
		'label' => esc_html__( 'Website Info', 'mithaecus' ),
		'section' => 'mithaecus_footer_options'
	));

	$wp_customize->add_setting('mithaecus_footer_background', array(
		'default' => 'dark',
		'transport' => 'postMessage',
		'sanitize_callback' => 'mithaecus_sanitize_footer_background'
	));

	$wp_customize->add_control('mithaecus_footer_background', array(
		'type' => 'select',
		'label' => esc_html__( 'Footer Background', 'mithaecus' ),
		'choices' => array(
			'light' => esc_html__( 'Light', 'mithaecus' ),
			'dark' => esc_html__( 'Dark', 'mithaecus' )
		),
		'section' => 'mithaecus_footer_options'
	));

	$wp_customize->add_setting('mithaecus_footer_layout', array(
		'default' => '3,3,3,3',
		'transport' => 'postMessage',
		'sanitize_callback' => 'sanitize_text_field',
		'validate_callback' => 'mithaecus_validate_footer_layout'
	));

	$wp_customize->add_control('mithaecus_footer_layout', array(
		'type' => 'text',
		'label' => esc_html__( 'Footer Layout', 'mithaecus' ),
		'section' => 'mithaecus_footer_options'
	));
}

add_action( 'customize_register', 'mithaecus_customize_register' );