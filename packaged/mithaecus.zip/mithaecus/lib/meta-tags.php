<?php

function mithaecus_add_meta_tags() {
	global $post;

	$description = is_single() ? get_the_excerpt( $post->ID ) : get_bloginfo( 'description' );
	
	echo '<meta name="Description" content="' . $description . '">';
	
}

add_action( 'wp_head', 'mithaecus_add_meta_tags' );